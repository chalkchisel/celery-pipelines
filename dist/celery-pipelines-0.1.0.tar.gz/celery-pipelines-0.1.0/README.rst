Celery Pipelines
---------------------
